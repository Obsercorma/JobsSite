<footer class="mt-auto pb-4 col-12 bg-dark text-white mt-5">

      <div class="container text-center">
  <br>
        <div class="row align-items-start ">

          <div class="col-md-6" id="scrollAPropos">
            <h4>Qui sommes-nous ?</h4>
            <a class="p-1 rounded" href="index.php#aPropos">A propos</a>

          </div>

          <div class="col-md-6">
            <h4>Confidentialité</h4>
            <a class="p-1 rounded" href="vue/confidentialite.html">A propos</a>
          </div>

        </div>
      </div>

  </footer>
</body>
</html>
