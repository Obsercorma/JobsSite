<?php

require_once("modele/mod_offre.php");

var_dump(applyAJob(12,26));
?>