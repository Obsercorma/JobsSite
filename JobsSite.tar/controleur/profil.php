<?php

$title_page = "Profil";

// affichage de  la    vue associée
include_once('vue/vue_profil.php');
