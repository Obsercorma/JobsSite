# Projet AP Jobs SIO2

## Emplacements :
- Fichiers SQL: `BDD Jobs` et `script SQL utilisateur` dans `/db/`

## Informations BDD :
-  Nom d'utilisateur: `bddjobs_user`
-  Mot de passe: `XhcwCxyEH/tBo@nH`
-  Nom de la BDD: `bddjobs`, encodage: `utf8_general_ci`
